"""
Secure Password Manager - Main Application File
--------------------------------------------------
This file contains all the routes (pages) and logic for:
- User registration & login (with hashed + salted passwords using bcrypt)
- Storing website credentials with encrypted passwords (using Fernet)
- A simple password generator
- Basic protection against SQL Injection, XSS, and CSRF
"""

import os
import secrets
import string
from datetime import datetime

from flask import Flask, render_template, redirect, url_for, request, flash, session
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from flask_wtf import CSRFProtect
from cryptography.fernet import Fernet
from functools import wraps

# ----------------------------------------------------------------------
# 1. APP SETUP
# ----------------------------------------------------------------------
app = Flask(__name__)

# Secret key is used by Flask to keep sessions/cookies secure.
# In a real production app, this should come from an environment variable.
app.config['SECRET_KEY'] = os.environ.get('FLASK_SECRET_KEY', 'change-this-secret-key-12345')

# SQLite database file (will be created automatically in the project folder)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///passwords.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
bcrypt = Bcrypt(app)
csrf = CSRFProtect(app)  # Protects all forms against CSRF attacks automatically

# ----------------------------------------------------------------------
# 2. ENCRYPTION KEY SETUP
# ----------------------------------------------------------------------
# This key is used to encrypt/decrypt the website passwords stored in the DB.
# It is generated ONCE and saved to a file called secret.key.
# IMPORTANT: Never delete secret.key after you start saving passwords,
# otherwise you will not be able to decrypt old entries.

KEY_FILE = 'secret.key'

if not os.path.exists(KEY_FILE):
    key = Fernet.generate_key()
    with open(KEY_FILE, 'wb') as f:
        f.write(key)
else:
    with open(KEY_FILE, 'rb') as f:
        key = f.read()

fernet = Fernet(key)


# ----------------------------------------------------------------------
# 3. DATABASE MODELS (TABLES)
# ----------------------------------------------------------------------
class User(db.Model):
    """Stores user accounts. Passwords are hashed+salted, never stored as plain text."""
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # One user can have many saved credentials
    credentials = db.relationship('Credential', backref='owner', lazy=True)


class Credential(db.Model):
    """Stores website credentials. The password is encrypted before saving."""
    id = db.Column(db.Integer, primary_key=True)
    website_name = db.Column(db.String(120), nullable=False)
    website_username = db.Column(db.String(120), nullable=False)
    encrypted_password = db.Column(db.LargeBinary, nullable=False)
    date_added = db.Column(db.DateTime, default=datetime.utcnow)

    # Link credential to the user who owns it
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)


# Create the database tables if they don't already exist
with app.app_context():
    db.create_all()


# ----------------------------------------------------------------------
# 4. HELPER FUNCTIONS
# ----------------------------------------------------------------------
def login_required(f):
    """Decorator that blocks access to a page unless the user is logged in."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in to continue.', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function


def generate_strong_password(length=14, use_symbols=True, use_numbers=True, use_uppercase=True):
    """Generates a random strong password using Python's 'secrets' module (cryptographically secure)."""
    letters = string.ascii_lowercase
    if use_uppercase:
        letters += string.ascii_uppercase
    if use_numbers:
        letters += string.digits
    if use_symbols:
        letters += "!@#$%^&*()-_=+"

    if length < 4:
        length = 4

    return ''.join(secrets.choice(letters) for _ in range(length))


# ----------------------------------------------------------------------
# 5. ROUTES (PAGES)
# ----------------------------------------------------------------------

@app.route('/')
def home():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))


# ---------------- REGISTER ----------------
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        confirm_password = request.form.get('confirm_password', '')

        # ---- Basic validation ----
        if not username or not email or not password:
            flash('All fields are required.', 'danger')
            return redirect(url_for('register'))

        if password != confirm_password:
            flash('Passwords do not match.', 'danger')
            return redirect(url_for('register'))

        if len(password) < 6:
            flash('Password must be at least 6 characters long.', 'danger')
            return redirect(url_for('register'))

        # Using SQLAlchemy ORM here automatically protects against SQL Injection
        existing_user = User.query.filter(
            (User.username == username) | (User.email == email)
        ).first()

        if existing_user:
            flash('Username or email already exists.', 'danger')
            return redirect(url_for('register'))

        # Hash + salt the password using bcrypt (salt is generated automatically)
        password_hash = bcrypt.generate_password_hash(password).decode('utf-8')

        new_user = User(username=username, email=email, password_hash=password_hash)
        db.session.add(new_user)
        db.session.commit()

        flash('Account created successfully! Please log in.', 'success')
        return redirect(url_for('login'))

    return render_template('register.html')


# ---------------- LOGIN ----------------
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')

        user = User.query.filter_by(username=username).first()

        # Check password against the stored bcrypt hash
        if user and bcrypt.check_password_hash(user.password_hash, password):
            session['user_id'] = user.id
            session['username'] = user.username
            flash(f'Welcome back, {user.username}!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid username or password.', 'danger')
            return redirect(url_for('login'))

    return render_template('login.html')


# ---------------- LOGOUT ----------------
@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('login'))


# ---------------- DASHBOARD ----------------
@app.route('/dashboard')
@login_required
def dashboard():
    # Only fetch credentials belonging to the logged-in user (access control)
    user_credentials = Credential.query.filter_by(user_id=session['user_id']).all()
    return render_template('dashboard.html', credentials=user_credentials)


# ---------------- ADD CREDENTIAL ----------------
@app.route('/add', methods=['GET', 'POST'])
@login_required
def add_credential():
    if request.method == 'POST':
        website_name = request.form.get('website_name', '').strip()
        website_username = request.form.get('website_username', '').strip()
        website_password = request.form.get('website_password', '')

        if not website_name or not website_username or not website_password:
            flash('All fields are required.', 'danger')
            return redirect(url_for('add_credential'))

        # Encrypt the password before storing it in the database
        encrypted = fernet.encrypt(website_password.encode('utf-8'))

        new_credential = Credential(
            website_name=website_name,
            website_username=website_username,
            encrypted_password=encrypted,
            user_id=session['user_id']
        )
        db.session.add(new_credential)
        db.session.commit()

        flash('Credential saved successfully!', 'success')
        return redirect(url_for('dashboard'))

    return render_template('add_credential.html')


# ---------------- VIEW (DECRYPT) A SINGLE CREDENTIAL ----------------
@app.route('/view/<int:credential_id>')
@login_required
def view_credential(credential_id):
    credential = Credential.query.get_or_404(credential_id)

    # Security check: make sure this credential belongs to the logged-in user
    if credential.user_id != session['user_id']:
        flash('You are not allowed to view this credential.', 'danger')
        return redirect(url_for('dashboard'))

    decrypted_password = fernet.decrypt(credential.encrypted_password).decode('utf-8')

    return render_template('view_credential.html', credential=credential, password=decrypted_password)


# ---------------- EDIT CREDENTIAL ----------------
@app.route('/edit/<int:credential_id>', methods=['GET', 'POST'])
@login_required
def edit_credential(credential_id):
    credential = Credential.query.get_or_404(credential_id)

    if credential.user_id != session['user_id']:
        flash('You are not allowed to edit this credential.', 'danger')
        return redirect(url_for('dashboard'))

    if request.method == 'POST':
        website_name = request.form.get('website_name', '').strip()
        website_username = request.form.get('website_username', '').strip()
        website_password = request.form.get('website_password', '')

        if not website_name or not website_username or not website_password:
            flash('All fields are required.', 'danger')
            return redirect(url_for('edit_credential', credential_id=credential.id))

        credential.website_name = website_name
        credential.website_username = website_username
        credential.encrypted_password = fernet.encrypt(website_password.encode('utf-8'))

        db.session.commit()
        flash('Credential updated successfully!', 'success')
        return redirect(url_for('dashboard'))

    # Decrypt current password to pre-fill the edit form
    current_password = fernet.decrypt(credential.encrypted_password).decode('utf-8')
    return render_template('edit_credential.html', credential=credential, current_password=current_password)


# ---------------- DELETE CREDENTIAL ----------------
@app.route('/delete/<int:credential_id>', methods=['POST'])
@login_required
def delete_credential(credential_id):
    credential = Credential.query.get_or_404(credential_id)

    if credential.user_id != session['user_id']:
        flash('You are not allowed to delete this credential.', 'danger')
        return redirect(url_for('dashboard'))

    db.session.delete(credential)
    db.session.commit()
    flash('Credential deleted.', 'info')
    return redirect(url_for('dashboard'))


# ---------------- PASSWORD GENERATOR (PAGE) ----------------
@app.route('/generate', methods=['GET', 'POST'])
@login_required
def generate_password_page():
    generated_password = None

    if request.method == 'POST':
        try:
            length = int(request.form.get('length', 14))
        except ValueError:
            length = 14

        use_symbols = 'use_symbols' in request.form
        use_numbers = 'use_numbers' in request.form
        use_uppercase = 'use_uppercase' in request.form

        generated_password = generate_strong_password(
            length=length,
            use_symbols=use_symbols,
            use_numbers=use_numbers,
            use_uppercase=use_uppercase
        )

    return render_template('generate_password.html', generated_password=generated_password)


# ----------------------------------------------------------------------
# 6. RUN THE APP
# ----------------------------------------------------------------------
if __name__ == '__main__':
    # debug=True is fine for development/demo purposes only.
    app.run(debug=True)
